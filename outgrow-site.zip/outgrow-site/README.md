# Outgrow — Marketing Site

All-season gear library for kids. Rent quality winter, rain, and sports gear for a small seasonal fee; return it when they grow.

## What's in here

- `index.html` — the entire site. One file, zero build step. Logo is embedded; GSAP, ScrollTrigger, and Lenis load from CDN.

## Run locally

Just open `index.html` in a browser, or:

```bash
python3 -m http.server 8000
# → http://localhost:8000
```

## Deploy (GitHub Pages)

1. Push this repo to GitHub
2. Repo → **Settings → Pages**
3. Source: **Deploy from a branch** → branch `main`, folder `/ (root)` → Save
4. Site goes live at `https://<username>.github.io/<repo-name>/` in ~1 minute

## Custom domain

1. Buy the domain (Namecheap, Cloudflare, Porkbun, etc.)
2. Repo → **Settings → Pages → Custom domain** → enter it (e.g. `outgrow.ca`) → Save
   (this auto-creates a `CNAME` file in the repo)
3. At your domain registrar, add DNS records:
   - **Apex domain** (`outgrow.ca`): four `A` records → `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
   - **www**: `CNAME` record → `<username>.github.io`
4. Back in Pages settings, tick **Enforce HTTPS** once the cert provisions (can take up to an hour)

## Contact

- Instagram: [@Outgrow__](https://instagram.com/Outgrow__)
- Email: OutGrow.ca@gmail.com
